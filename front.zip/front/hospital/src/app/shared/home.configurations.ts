export const BASE_URL_BACKEND = 'http://localhost:8080/practica/reservas/';
export const CONSULTA_RESERVAS = 'consultaReservas';
export const BASE_URL_BACKEND_POST = 'http://localhost:8080/practica/reservas';

export const URL_REPORTE = 'reporte';